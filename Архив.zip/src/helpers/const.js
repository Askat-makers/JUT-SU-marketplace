export const watchesApi = "http://localhost:8000/watches";
