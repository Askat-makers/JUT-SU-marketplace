import React from "react";

function MainPage() {
  return <div>MainPage</div>;
}

export default MainPage;
