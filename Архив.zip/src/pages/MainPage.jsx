import React from "react";
import { Container } from "@mui/material";

function MainPage() {
  return (
    <div className="main-page">
      <Container>
        <h2>Весь каталог часов</h2>
      </Container>
    </div>
  );
}

export default MainPage;
